"""OpenCivic — users endpoints. Full implementation follows scaffold in Phase 3."""
from fastapi import APIRouter
router = APIRouter()
